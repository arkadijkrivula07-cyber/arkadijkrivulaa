<?php
include 'route.php';
$r = new Route();
$r->start();
?>
